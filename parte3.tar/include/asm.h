#ifndef __ASM_H__
#define __ASM_H__
#include <stdio.h>
#include <stdlib.h>
int assemble(const char *filename, FILE *input, FILE *output);
#endif
