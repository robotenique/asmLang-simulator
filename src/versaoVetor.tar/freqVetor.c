/*
 * @author: Juliano Garcia de Oliveira
 * @author: Enzo Hideki Nakamura
 *
 * MAC0216
 *
 * SymbolTable test: Frequency of words in a text
 */
#include "../include/buffer.h"
#include "../include/error.h"
#include "../include/stable.h"
#include <ctype.h>
#include <stdlib.h>
#include <string.h>
#include <mcheck.h>

typedef struct {
    char* p;
    unsigned int freq;
} word;
word *totalW;
unsigned int wide =0, nwords =0, ind = 0;
int max(int a, int b);
int visit(const char *key, EntryData *data);
int compare (const void * a, const void * b);

int main(int argc, char **argv) {
    mcheck(0);

    SymbolTable st = stable_create();
    Buffer *B = buffer_create();
    Buffer *W = buffer_create();
    set_prog_name("freq.c");
    // Input verification
    if (argc != 2)
        die("Wrong number of arguments, aborting...");
    //FILE* input = fopen("input", "r");
    FILE* input = fopen(argv[1], "r");
    if (input == NULL)
       die("Error opening file, aborting...");

    while(read_line(input,B)) {
        int i;
        buffer_push_back(B,0);
        for (i = 0; isspace(B->data[i]) && B->data[i]!=0; i++);
        while (B->data[i]!=0) {
            while (!isspace(B->data[i]) && B->data[i] != 0 && i < (B -> i))
                buffer_push_back(W,B->data[i++]);
            i++;
            if(W->i != 0) {
                buffer_push_back(W,0);
                wide = max(wide, W->i);
                InsertionResult ir = stable_insert(st, W->data);
                if(ir.new)
                    nwords++;
                    (*ir.data).i = 1 + (!ir.new * (*ir.data).i);
            }
            buffer_reset(W);
        }
    }
    totalW = emalloc(nwords*sizeof(word));
    stable_visit(st, &visit);
    //Print the words in the specified format and order
    qsort(totalW, nwords, sizeof(word), compare);
    for (int i=0; i<nwords; i++)
    printf("%s %*d\n", totalW[i].p, (int) (wide - strlen(totalW[i].p)), totalW[i].freq);


}

int visit(const char *key, EntryData *data) {
    if(strlen(key) == 0)
        printf("UAU and ind = %d\n",ind);
    totalW[ind].p = emalloc(strlen(key));
    strcpy(totalW[ind].p, key);
    totalW[ind].freq = data -> i;
    ind++;
    return 1;
}

int max(int a, int b){return a > b ? a : b;}
/*
 * Function: compare
 * --------------------------------------------------------
 *   Receives two pointers and compare them lexicographically, according to
 * their words.
 * @args a: First pointer
 *       b: Second pointer
 * @return  < 0, if 'a' has a word less than the word of 'b'.
 *          > 0, if 'b' has a word less than the word of 'a'.
 *          = 0, if 'a' has a word equal to the word of 'b'.
 */
int compare (const void * a, const void * b){
  return strcmp(((word *)a)->p, ((word *)b)->p);
}
